import copy
import importlib.util
import itertools
import pathlib
import unittest

MODULE = pathlib.Path(__file__).resolve().parents[1] / "scripts" / "decide.py"
spec = importlib.util.spec_from_file_location("decide", MODULE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def base():
    return {
        "diff": "main...HEAD",
        "dimensions": {k: {"score": 0, "evidence": "verified from diff and matching tests"} for k in module.DIMENSIONS},
        "gates": {k: {"status": "no", "evidence": "reviewed diff: no active change"} for k in module.GATES},
    }


class RouteCases(unittest.TestCase):
    def test_normal_docs(self):
        self.assertEqual(module.decide(base())["mode"], "NORMAL")

    def test_boundary_score_two_is_focused(self):
        a = base(); a["dimensions"]["uncertainty"]["score"] = 2
        self.assertEqual(module.decide(a)["mode"], "FOCUSED")

    def test_total_two_normal(self):
        a = base(); a["dimensions"]["impact"]["score"] = 1
        a["dimensions"]["scope"]["score"] = 1
        self.assertEqual(module.decide(a)["mode"], "NORMAL")

    def test_total_three_focused(self):
        a = base()
        for k in ("impact", "scope", "verification"):
            a["dimensions"][k]["score"] = 1
        self.assertEqual(module.decide(a)["mode"], "FOCUSED")

    def test_total_six_full(self):
        a = base()
        for k in ("impact", "scope", "uncertainty", "verification", "recovery"):
            a["dimensions"][k]["score"] = {"impact": 1, "scope": 2, "uncertainty": 1, "verification": 1, "recovery": 1}[k]
        self.assertEqual(module.decide(a)["mode"], "FULL")

    def test_high_impact_overrides_low_total(self):
        a = base(); a["dimensions"]["impact"]["score"] = 2
        self.assertEqual(module.decide(a)["mode"], "FULL")

    def test_irreversible_overrides_low_total(self):
        a = base(); a["dimensions"]["recovery"]["score"] = 2
        self.assertEqual(module.decide(a)["mode"], "FULL")

    def test_every_gate_overrides(self):
        for gate in module.GATES:
            with self.subTest(gate=gate):
                a = base(); a["gates"][gate]["status"] = "yes"
                self.assertEqual(module.decide(a)["mode"], "FULL")
                self.assertEqual(module.decide(a)["state"], "FINAL")

    def test_unknown_gate_full_provisional(self):
        a = base(); a["gates"]["AUTH"]["status"] = "unknown"
        result = module.decide(a)
        self.assertEqual((result["mode"], result["state"]), ("FULL", "PROVISIONAL"))

    def test_unknown_dimension_not_zero(self):
        a = base(); a["dimensions"]["scope"]["score"] = None
        result = module.decide(a)
        self.assertEqual((result["mode"], result["state"], result["routing_score"]), ("FOCUSED", "PROVISIONAL", 2))

    def test_unknown_impact_full(self):
        a = base(); a["dimensions"]["impact"]["score"] = None
        self.assertEqual(module.decide(a)["mode"], "FULL")

    def test_compound_untested_complex_full(self):
        a = base()
        a["dimensions"]["uncertainty"]["score"] = 2
        a["dimensions"]["verification"]["score"] = 2
        self.assertEqual(module.decide(a)["mode"], "FULL")

    def test_compound_cross_boundary_untested_full(self):
        a = base()
        a["dimensions"]["scope"]["score"] = 2
        a["dimensions"]["verification"]["score"] = 2
        self.assertEqual(module.decide(a)["mode"], "FULL")

    def test_unknowns_increase_upper_bound_to_full(self):
        a = base()
        for k in ("scope", "uncertainty", "verification"):
            a["dimensions"][k]["score"] = None
        self.assertEqual(module.decide(a)["mode"], "FULL")

    def test_missing_evidence_rejected(self):
        a = base(); a["dimensions"]["scope"]["evidence"] = ""
        with self.assertRaises(module.InvalidAssessment): module.decide(a)

    def test_missing_gate_rejected(self):
        a = base(); del a["gates"]["AUTH"]
        with self.assertRaises(module.InvalidAssessment): module.decide(a)

    def test_bool_score_rejected(self):
        a = base(); a["dimensions"]["impact"]["score"] = True
        with self.assertRaises(module.InvalidAssessment): module.decide(a)

    def test_unexpected_keys_rejected(self):
        a = base(); a["other"] = 5
        with self.assertRaises(module.InvalidAssessment): module.decide(a)

    def test_score_monotonicity_exhaustive(self):
        levels = {"NORMAL": 0, "FOCUSED": 1, "FULL": 2}
        for values in itertools.product(range(3), repeat=5):
            a = base()
            for k, v in zip(module.DIMENSIONS, values):
                a["dimensions"][k]["score"] = v
            first = levels[module.decide(a)["mode"]]
            for k in module.DIMENSIONS:
                if a["dimensions"][k]["score"] < 2:
                    b = copy.deepcopy(a)
                    b["dimensions"][k]["score"] += 1
                    self.assertGreaterEqual(levels[module.decide(b)["mode"]], first)

    def test_all_unknown_is_provisional_full(self):
        a = base()
        for k in module.DIMENSIONS:
            a["dimensions"][k]["score"] = None
        r = module.decide(a)
        self.assertEqual((r["mode"], r["state"], r["routing_score"]), ("FULL", "PROVISIONAL", 10))

    def test_invalid_gate_status_rejected(self):
        a = base(); a["gates"]["AUTH"]["status"] = "maybe"
        with self.assertRaises(module.InvalidAssessment): module.decide(a)


if __name__ == "__main__":
    unittest.main()
