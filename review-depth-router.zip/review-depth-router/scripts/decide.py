#!/usr/bin/env python3
"""Deterministic routing from *human/agent-supplied*, evidence-backed scores.

It does not inspect git diff or judge whether evidence is truthful.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

DIMENSIONS = ("impact", "scope", "uncertainty", "verification", "recovery")
GATES = ("AUTH", "SECRETS", "EXECUTION", "DESTRUCTIVE", "SECURITY_GATE", "AUTONOMOUS_EFFECT")


class InvalidAssessment(ValueError):
    pass


def _validate_fields(data, expected, label):
    if not isinstance(data, dict) or set(data) != set(expected):
        raise InvalidAssessment(f"{label} must contain exactly: {', '.join(expected)}")


def _evidence(value, label):
    if not isinstance(value, str) or not value.strip():
        raise InvalidAssessment(f"{label}: nonempty evidence required")


def decide(data: dict) -> dict:
    if not isinstance(data, dict) or set(data) != {"diff", "dimensions", "gates"}:
        raise InvalidAssessment("assessment requires exactly diff, dimensions, gates")
    _evidence(data["diff"], "diff")
    _validate_fields(data["dimensions"], DIMENSIONS, "dimensions")
    _validate_fields(data["gates"], GATES, "gates")

    scores = {}
    unresolved = []
    for name in DIMENSIONS:
        record = data["dimensions"][name]
        _validate_fields(record, ("score", "evidence"), name)
        _evidence(record["evidence"], name)
        score = record["score"]
        if score is not None and (type(score) is not int or score not in (0, 1, 2)):
            raise InvalidAssessment(f"{name}: score must be 0, 1, 2, or null")
        scores[name] = score
        if score is None:
            unresolved.append(name)

    triggered = []
    uncertain_gates = []
    for name in GATES:
        record = data["gates"][name]
        _validate_fields(record, ("status", "evidence"), name)
        _evidence(record["evidence"], name)
        if record["status"] not in ("yes", "no", "unknown"):
            raise InvalidAssessment(f"{name}: status must be yes, no, or unknown")
        if record["status"] == "yes":
            triggered.append(name)
        elif record["status"] == "unknown":
            uncertain_gates.append(name)

    observed_sum = sum(score for score in scores.values() if score is not None)
    routing_scores = {key: (2 if value is None else value) for key, value in scores.items()}
    upper_bound = sum(routing_scores.values())
    if triggered or uncertain_gates:
        mode = "FULL"
        reason = "hard gate"
    elif routing_scores["impact"] == 2 or routing_scores["recovery"] == 2:
        mode = "FULL"
        reason = "high impact or irreversible recovery"
    elif routing_scores["verification"] == 2 and (routing_scores["uncertainty"] == 2 or routing_scores["scope"] == 2):
        mode = "FULL"
        reason = "untested complex or cross-boundary change"
    elif upper_bound >= 6:
        mode = "FULL"
        reason = "conservative total >= 6"
    elif upper_bound >= 3 or 2 in routing_scores.values():
        mode = "FOCUSED"
        reason = "conservative total >= 3 or a single score of 2"
    else:
        mode = "NORMAL"
        reason = "low total with no overrides"

    provisional = bool(unresolved or uncertain_gates)
    return {
        "mode": mode,
        "state": "PROVISIONAL" if provisional else "FINAL",
        "observed_score": observed_sum,
        "routing_score": upper_bound,
        "triggered_gates": triggered,
        "uncertain_gates": uncertain_gates,
        "unknown_dimensions": unresolved,
        "reason": reason,
        "merge_approval": "NOT_GRANTED",
        "next_step": "Resolve missing facts once; if unavailable stop automatic retries and request human decision" if provisional else "Perform the selected review; do not infer merge approval",
    }


def main():
    if len(sys.argv) != 2:
        print("usage: python3 scripts/decide.py assessment.json", file=sys.stderr)
        return 2
    try:
        assessment = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
        print(json.dumps(decide(assessment), ensure_ascii=False, indent=2))
    except (OSError, ValueError) as exc:
        print(f"invalid assessment: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
