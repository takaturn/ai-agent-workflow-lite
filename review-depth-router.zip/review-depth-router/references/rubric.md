# Evidence-based scoring policy (version 1.0)

**Unit of assessment:** the changes introduced by the exact diff compared with its base, including affected execution paths. An assertion about a *plausible* failure must name the changed behavior and the path by which the failure could happen. Don't assume every theoretical catastrophe is plausible. Use the **highest applicable score**, not an average; the listed cases are ordered 2 > 1 > 0. An unverified fact is `null`, not `0`.

## Five dimensions (0–2 each)

| Dimension | 2 — use if… | 1 — otherwise use if… | 0 — only if… |
|---|---|---|---|
| `impact` | A failure plausibly causes unauthorized disclosure/action, loss/corruption of persistent real data, or outage of an entire separately deployed service (not merely one feature). Name the causal path. | A failure plausibly changes functional results or availability of a bounded feature without a score-2 effect. | Changed content has no plausible effect on runtime behavior or users’ consequential actions (e.g. typo-only docs, comments, purely cosmetic display, or isolated tests with no removal/weakening of safety checks). |
| `scope` | Changes an interface or behavior consumed **across process/service/repository boundaries** (e.g. IPC, externally consumed API, event schema), or changes a repo-wide execution policy. Cite the boundary. | Changes behavior reached from **two or more distinct runtime entrypoints in one process** (HTTP routes, CLI subcommands, jobs or event handlers), or changes an exported in-process interface consumed by another component. Cite the entrypoints/caller. | Either (a) change is non-executable content and alters no externally relied-upon technical contract, or (b) call graph/entrypoint inspection shows the changed behavior is reached from **only one runtime entrypoint**, with no changed outward contract. |
| `uncertainty` | Introduces/changes shared mutable state, concurrency, ordering dependencies, retry/timeout/idempotency semantics, or a new communication protocol/schema between independently executed components. | Adds/changes branches, input validation or error handling, but none of the score-2 conditions. | No new or modified functional control flow/state, or behavioral equivalence is demonstrated by relevant passing tests and diff comparison. |
| `verification` | No observed passing executable check relevant to the changed behavior; relevant checks fail/are flaky; or execution of required checks is unavailable. | Passing tests/manual checks exist, but do not cover a significant altered boundary/failure path; or only manual checks cover it. | A passing executable check covers the changed behavior and any applicable changed failure/boundary path. For non-executable-only diffs, direct inspection of changed claims and links suffices **unless** they include runnable commands, safety guidance or externally relied-upon contracts; those need relevant verification. |
| `recovery` | Failure can leave durable/external side effects that source rollback cannot repair (e.g. deleted records, sent messages, leaked secrets); reversal requires data reconstruction. | Rollback needs documented reversible migration, data cleanup, or operational intervention. | Reverting code/config suffices to restore behavior without repairing durable/external side effects. |

**Terms and tie-breaking**

- **Runtime entrypoint**: distinct CLI subcommand, HTTP handler, scheduled job, event handler or separately invoked tool. **Component**: functional unit called from an entrypoint; directory names, function counts and changed line counts do not define it. If the call graph/consumers cannot be traced with repository evidence, scope is `null`. **Service**: separately deployed or operated execution unit. **Contract**: public API, CLI option/exit status, event/schema, or behavior relied upon by a separately maintained caller. Cite actual callers or definitions; if not discoverable, mark scope `null`.
- **Cosmetic** means no change to business semantics, exported behavior, user action or accessible data; merely labeling a production file `UI` does not make it cosmetic. Docs that teach unsafe executable commands or leak secrets are not automatically harmless simply because they are not executed by the application.
- **Equivalent behavior** requires evidence from the diff plus relevant passing regression tests; “looks similar” or “common pattern” alone never earns uncertainty 0. If the behavior is not demonstrably equivalent, use score 1 or 2 as applicable.
- A change to **tests only** may score impact 0 if it does not weaken a mandatory verification/security gate. **Mandatory gate** means a check enforced by the repository branch protection, release/deployment policy or required CI workflow; deleting an optional test case alone is not automatically a hard gate. A change that weakens such a gate is a hard gate regardless of production-code diff.
- **Passing check** means an actual observed result, not a plan to run tests. If a test covers the changed happy path but not the changed negative path, verification is **1**. If no passing test/check is relevant to the changed behavior at all, verification is **2**.
- **Real data** excludes disposable test fixtures but includes users' files, deployed databases, shared environments and external requests with lasting consequences.
- For a score of 0, cite positive evidence for the harmless property (e.g. only doc lines modified), not merely “no issue seen.”
- If any score has two plausible interpretations due to a missing factual premise, mark it `null`; gather that fact before relying on the routing decision.

## Six hard gates

Evaluate each for **behavior changed by this diff**. `yes` => FULL, `unknown` => FULL/PROVISIONAL; `no` requires a diff-based justification. A keyword appearing in README or an added negative test is **not** automatically a gate.

| ID | Yes when active behavior changes… |
|---|---|
| `AUTH` | Authentication, authorization, identity/trust-boundary enforcement, or privilege checks. |
| `SECRETS` | Secret collection, storage, redaction, logging, distribution or exposure paths. |
| `EXECUTION` | Shell/tool execution permission, agent approval, sandbox confinement or network egress restrictions. |
| `DESTRUCTIVE` | Real-data deletion, non-backward-compatible schema migration, or cleanup selection that can affect durable data. |
| `SECURITY_GATE` | Enforcement of mandatory security checks, CI gates, review requirements, or equivalent guardrails is weakened/bypassed. This includes changes to required-check configuration, not ordinary test-case maintenance by itself. Mere addition of tests is not a weakening. |
| `AUTONOMOUS_EFFECT` | Autonomous agent/action can create external or durable side effects (including changing approval rules, side-effecting retries or recipient/target selection). A change must alter which side effects the agent can initiate without a fresh approval, which targets it may affect, or side-effecting retries. Pure model-choice refactors with unchanged capabilities and tool policy do not qualify. |

**Gate-negative evidence** can be compact, but must refer to the diff examined: e.g. “Only README section changed; no executable files, policies or workflows modified.” Avoid reasoning only from path names; inspect contents.

## Required assessment JSON

All five dimensions and all six gates are mandatory. `score` may be `null`; gate `status` is `yes`, `no`, or `unknown`. For every score/gate include nonempty `evidence` (for unknown: the missing fact). The script validates the structure, computes routing, and reports uncertainty; it does **not** inspect the diff or prove factual scores correct.

```json
{
  "diff": "origin/main...HEAD",
  "dimensions": {
    "impact": {"score": 1, "evidence": "changed CLI option alters one feature's output"},
    "scope": {"score": 1, "evidence": "public CLI option used by two internal callers"},
    "uncertainty": {"score": 1, "evidence": "new input-validation branch"},
    "verification": {"score": 1, "evidence": "happy path test passes; invalid input not tested"},
    "recovery": {"score": 0, "evidence": "no external writes; revert restores old behavior"}
  },
  "gates": {
    "AUTH": {"status": "no", "evidence": "no authentication decisions changed in diff"},
    "SECRETS": {"status": "no", "evidence": "no secret handling changed in diff"},
    "EXECUTION": {"status": "no", "evidence": "no execution policy changed in diff"},
    "DESTRUCTIVE": {"status": "no", "evidence": "no persistent deletion or migration changed"},
    "SECURITY_GATE": {"status": "no", "evidence": "CI enforcement unchanged"},
    "AUTONOMOUS_EFFECT": {"status": "no", "evidence": "no autonomous side effects changed"}
  }
}
```

## Examples clarifying ambiguity

| Diff evidence | Classification notes | Expected mode |
|---|---|---|
| README typo only; diff inspection completed | `impact=0`, all remaining dimensions 0 (non-executable diff), no gates | NORMAL |
| Single function display formatting changed, executable test passes | `impact=0`, `scope=0`, `uncertainty=0`, `verification=0`, `recovery=0` | NORMAL |
| New parameter validation; relevant negative test absent | `impact=1`, `uncertainty=1`, `verification=1`; other dimensions 0 | FOCUSED |
| Change to retry logic; side-effect free fetch; some tests | `uncertainty=2` => at least FOCUSED even if total only 2 | FOCUSED |
| Change to side-effecting autonomous retry | `AUTONOMOUS_EFFECT=yes` | FULL |
| Retry/ordering semantics changed and no relevant passing test | `uncertainty=2`, `verification=2`: compound override | FULL |
| A one-line authorization bypass | `AUTH=yes` (regardless of total) | FULL |
| Deleted regression test that disables a mandatory CI guard | `SECURITY_GATE=yes` | FULL |
| Documentation *about* authentication, no active behavior changed | `AUTH=no`; assess docs normally | NORMAL |
| Unable to establish consumers of an exported function | `scope=null`, PROVISIONAL; null scored conservatively as 2 for routing | FOCUSED or FULL depending on other scores |
| Unable to tell whether authorization is modified | `AUTH=unknown` | FULL / PROVISIONAL |

## Output contract

Report the mode (NORMAL/FOCUSED/FULL), state (FINAL/PROVISIONAL), summed observed scores and conservative routing score, hard-gate reasons, plus concrete targeted review scenarios. Do not silently convert unresolved risk into a final classification. A FINAL routing decision is **not** a safety or merge approval.
